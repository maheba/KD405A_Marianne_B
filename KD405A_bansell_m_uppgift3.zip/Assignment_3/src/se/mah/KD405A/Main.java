package se.mah.KD405A;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Main extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		Random rand = new Random();
		
		ArrayList<Bike> myBikes = new ArrayList<Bike>();
		for (int i=0; i<10; i++) {
			myBikes.add(new Bike(Constants.COLORARRAY[rand.nextInt(5)], rand.nextInt(20)+8, rand.nextInt(30000)));
				
			//Print it all out
			System.out.println("Cykel " + (i+1) + " - Pris: " + myBikes.get(i).getPrice() + " kr, " + " F�rg: " + myBikes.get(i).getColor() + " , Storlek: " + myBikes.get(i).getSize() + " tum.");
		}
	}
}
